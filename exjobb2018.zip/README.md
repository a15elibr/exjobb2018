# exjobb2018
The 'official' repo for my thesis project.

### A quick introduction
This project introduces <img src="https://raw.githubusercontent.com/a15elibr/exjobb2018/master/testning/migwiz1/public/images/mini.png" width="15"> **MigWiz**, a wizard for database migration from MySQL to MongoDB for CMS MultiSites. 
